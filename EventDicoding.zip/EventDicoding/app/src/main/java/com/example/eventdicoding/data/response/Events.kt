package com.example.eventdicoding.data.response


data class Events(
    val id: String,
    val name: String,
    val ownerName: String,
    val beginTime: String?,
    val quota: Int,
    val registrants: Int,
    val description: String,
    val link: String,
    val mediaCover: String
)
