package com.example.eventdicoding.ui

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.eventdicoding.data.response.DetailResponse
import com.example.eventdicoding.data.response.Event
import com.example.eventdicoding.data.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailViewModel : ViewModel() {

    private val _event = MutableLiveData<Event?>()
    val event: MutableLiveData<Event?> get() = _event

    fun fetchEventDetail(eventId: Int) {
        ApiConfig.getApiService().getEventDetail(eventId).enqueue(object : Callback<DetailResponse> {
            override fun onResponse(call: Call<DetailResponse>, response: Response<DetailResponse>) {
                if (response.isSuccessful) {
                    val event = response.body()?.event
                    Log.d("DetailViewModel", "Response body: $event")
                    if (event != null) {
                        _event.value = event

                    } else {
                        Log.e("DetailViewModel", "Event is null")
                        _event.value = null
                    }
                } else {
                    Log.e("DetailViewModel", "Failed to get event details: ${response.message()}")
                    _event.value = null
                }
            }

            override fun onFailure(call: Call<DetailResponse>, t: Throwable) {
                Log.e("DetailViewModel", "API call failed: ${t.message}")
                _event.value = null
                t.printStackTrace()
            }
        })
    }
}
