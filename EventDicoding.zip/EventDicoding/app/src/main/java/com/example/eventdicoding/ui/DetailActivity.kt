package com.example.eventdicoding.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.HtmlCompat
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.example.eventdicoding.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private lateinit var viewModel: DetailViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val eventId = intent.getIntExtra("id", 0)
        Log.d("DetailActivity", "Event ID: $eventId")

        if (eventId != 0) {
            viewModel = ViewModelProvider(this).get(DetailViewModel::class.java)
            viewModel.fetchEventDetail(eventId)
        } else {
            Log.e("DetailActivity", "Invalid Event ID")
        }

        viewModel.event.observe(this) { event ->
            if (event != null) {
                binding.eventTitle.text = event.name
                binding.eventOrganizer.text = event.ownerName
                binding.eventTime.text = "Time: ${event.beginTime ?: "Lorem"}"
                binding.eventQuota.text = "Sisa Quota: ${(event.quota ?: 0) - (event.registrants ?: 0)}"
                binding.eventDescription.text = HtmlCompat.fromHtml(event.description.toString(), HtmlCompat.FROM_HTML_MODE_LEGACY)
                Glide.with(this).load(event.mediaCover).into(binding.eventImage)

                binding.btnRegister.setOnClickListener {
                    val eventLink = event.link ?: "https://www.dicoding.com/events/8722"
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(eventLink)))
                }
            } else {
                Log.e("DetailActivity", "Event data is null")
            }
        }
    }
}
